I removed the contents of the "packages" folder because they added 
around 560MB to the project folder making it too large to upload.

Here is what I removed:

System.Buffers.4.4.0
System.Collections.Immutable.1.3.1
System.Memory.4.5.2
System.Numerics.Vectors.4.5.0
System.Runtime.CompilerServices.Unsafe.4.5.2
System.Runtime.InteropServices.WindowsRuntime.4.3.0
Uno.Diagnostics.Eventing.2.0.1
Uno.Foundation.Logging.4.0.11
Uno.SourceGenerationTasks.4.0.0
Uno.UI.4.0.11
