﻿namespace MollysGameSaveMule
{
    partial class messageBoxForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label_TitleBar = new System.Windows.Forms.Label();
            this.btn_OK = new System.Windows.Forms.Button();
            this.btn_Yes = new System.Windows.Forms.Button();
            this.btn_No = new System.Windows.Forms.Button();
            this.label_Message = new System.Windows.Forms.Label();
            this.panel_Border = new System.Windows.Forms.Panel();
            this.panel_Border.SuspendLayout();
            this.SuspendLayout();
            // 
            // label_TitleBar
            // 
            this.label_TitleBar.BackColor = System.Drawing.Color.Transparent;
            this.label_TitleBar.Font = new System.Drawing.Font("Heavitas", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_TitleBar.ForeColor = System.Drawing.Color.Orange;
            this.label_TitleBar.Location = new System.Drawing.Point(29, 20);
            this.label_TitleBar.Name = "label_TitleBar";
            this.label_TitleBar.Padding = new System.Windows.Forms.Padding(0, 10, 0, 0);
            this.label_TitleBar.Size = new System.Drawing.Size(415, 49);
            this.label_TitleBar.TabIndex = 1;
            this.label_TitleBar.Text = "Title Here";
            this.label_TitleBar.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label_TitleBar.MouseMove += new System.Windows.Forms.MouseEventHandler(this.window_MouseMove);
            // 
            // btn_OK
            // 
            this.btn_OK.BackColor = System.Drawing.Color.Orange;
            this.btn_OK.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btn_OK.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_OK.Font = new System.Drawing.Font("Heavitas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_OK.ForeColor = System.Drawing.Color.Black;
            this.btn_OK.Location = new System.Drawing.Point(184, 388);
            this.btn_OK.Name = "btn_OK";
            this.btn_OK.Size = new System.Drawing.Size(100, 30);
            this.btn_OK.TabIndex = 9;
            this.btn_OK.Text = "OK";
            this.btn_OK.UseVisualStyleBackColor = false;
            this.btn_OK.Visible = false;
            // 
            // btn_Yes
            // 
            this.btn_Yes.BackColor = System.Drawing.Color.Orange;
            this.btn_Yes.DialogResult = System.Windows.Forms.DialogResult.Yes;
            this.btn_Yes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Yes.Font = new System.Drawing.Font("Heavitas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Yes.ForeColor = System.Drawing.Color.Black;
            this.btn_Yes.Location = new System.Drawing.Point(131, 388);
            this.btn_Yes.Name = "btn_Yes";
            this.btn_Yes.Size = new System.Drawing.Size(100, 30);
            this.btn_Yes.TabIndex = 2;
            this.btn_Yes.Text = "Yes";
            this.btn_Yes.UseVisualStyleBackColor = false;
            this.btn_Yes.Visible = false;
            // 
            // btn_No
            // 
            this.btn_No.BackColor = System.Drawing.Color.Orange;
            this.btn_No.DialogResult = System.Windows.Forms.DialogResult.No;
            this.btn_No.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_No.Font = new System.Drawing.Font("Heavitas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_No.ForeColor = System.Drawing.Color.Black;
            this.btn_No.Location = new System.Drawing.Point(237, 388);
            this.btn_No.Name = "btn_No";
            this.btn_No.Size = new System.Drawing.Size(100, 30);
            this.btn_No.TabIndex = 3;
            this.btn_No.Text = "No";
            this.btn_No.UseVisualStyleBackColor = false;
            this.btn_No.Visible = false;
            // 
            // label_Message
            // 
            this.label_Message.BackColor = System.Drawing.Color.Transparent;
            this.label_Message.Font = new System.Drawing.Font("Heavitas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Message.ForeColor = System.Drawing.Color.Orange;
            this.label_Message.Location = new System.Drawing.Point(25, 58);
            this.label_Message.Name = "label_Message";
            this.label_Message.Padding = new System.Windows.Forms.Padding(0, 10, 0, 0);
            this.label_Message.Size = new System.Drawing.Size(419, 319);
            this.label_Message.TabIndex = 10;
            this.label_Message.Text = "Text Here";
            this.label_Message.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label_Message.MouseMove += new System.Windows.Forms.MouseEventHandler(this.window_MouseMove);
            // 
            // panel_Border
            // 
            this.panel_Border.BackColor = System.Drawing.Color.Black;
            this.panel_Border.Controls.Add(this.btn_Yes);
            this.panel_Border.Controls.Add(this.btn_No);
            this.panel_Border.Controls.Add(this.btn_OK);
            this.panel_Border.Controls.Add(this.label_TitleBar);
            this.panel_Border.Controls.Add(this.label_Message);
            this.panel_Border.Location = new System.Drawing.Point(0, 6);
            this.panel_Border.Name = "panel_Border";
            this.panel_Border.Size = new System.Drawing.Size(470, 436);
            this.panel_Border.TabIndex = 11;
            this.panel_Border.MouseMove += new System.Windows.Forms.MouseEventHandler(this.window_MouseMove);
            // 
            // messageBoxForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Orange;
            this.ClientSize = new System.Drawing.Size(470, 448);
            this.Controls.Add(this.panel_Border);
            this.ForeColor = System.Drawing.Color.Transparent;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.Name = "messageBoxForm";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.window_MouseMove);
            this.panel_Border.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label_TitleBar;
        private System.Windows.Forms.Button btn_OK;
        private System.Windows.Forms.Button btn_Yes;
        private System.Windows.Forms.Button btn_No;
        private System.Windows.Forms.Label label_Message;
        private System.Windows.Forms.Panel panel_Border;
    }
}