﻿namespace MollysGameSaveMule
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.btn_XboxToSteam = new System.Windows.Forms.Button();
            this.btn_SteamToXbox = new System.Windows.Forms.Button();
            this.gb_Transfer = new System.Windows.Forms.GroupBox();
            this.btn_AutoSync = new System.Windows.Forms.Button();
            this.btn_LocateSteamSave = new System.Windows.Forms.Button();
            this.btn_LocateXboxSave = new System.Windows.Forms.Button();
            this.label_StatusInfo = new System.Windows.Forms.Label();
            this.menuStrip_Main = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.setBackupFolderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.chooseBackupFolderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.resetDefaultBackupFolderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.setSteamSaveFolderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.chooseSteamSaveFolderToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.resetDefaultSteamSaveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.setXboxSaveFolderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.chooseXboxSaveFolderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.resetDefaultXboxToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.restoreAllDefaultFoldersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.backupToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.restoreBackupsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.restoreAllToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.restoreSteamToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.restoreXboxToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pictureBoxMolly = new System.Windows.Forms.PictureBox();
            this.label_Title = new System.Windows.Forms.Label();
            this.btn_Close = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.btn_Minimize = new System.Windows.Forms.Button();
            this.gb_Saves = new System.Windows.Forms.GroupBox();
            this.btn_LocateXboxBackup = new System.Windows.Forms.Button();
            this.btn_LocateSteamBackup = new System.Windows.Forms.Button();
            this.gb_Backups = new System.Windows.Forms.GroupBox();
            this.panel_Border = new System.Windows.Forms.Panel();
            this.gb_Transfer.SuspendLayout();
            this.menuStrip_Main.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxMolly)).BeginInit();
            this.gb_Saves.SuspendLayout();
            this.gb_Backups.SuspendLayout();
            this.panel_Border.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_XboxToSteam
            // 
            this.btn_XboxToSteam.BackColor = System.Drawing.Color.Orange;
            this.btn_XboxToSteam.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_XboxToSteam.ForeColor = System.Drawing.Color.Black;
            this.btn_XboxToSteam.Location = new System.Drawing.Point(9, 90);
            this.btn_XboxToSteam.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btn_XboxToSteam.Name = "btn_XboxToSteam";
            this.btn_XboxToSteam.Size = new System.Drawing.Size(237, 29);
            this.btn_XboxToSteam.TabIndex = 2;
            this.btn_XboxToSteam.Text = "Xbox to Steam";
            this.btn_XboxToSteam.UseVisualStyleBackColor = false;
            this.btn_XboxToSteam.Click += new System.EventHandler(this.btn_XboxToSteam_Click);
            // 
            // btn_SteamToXbox
            // 
            this.btn_SteamToXbox.BackColor = System.Drawing.Color.Orange;
            this.btn_SteamToXbox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_SteamToXbox.ForeColor = System.Drawing.Color.Black;
            this.btn_SteamToXbox.Location = new System.Drawing.Point(9, 55);
            this.btn_SteamToXbox.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btn_SteamToXbox.Name = "btn_SteamToXbox";
            this.btn_SteamToXbox.Size = new System.Drawing.Size(237, 29);
            this.btn_SteamToXbox.TabIndex = 1;
            this.btn_SteamToXbox.Text = "Steam to Xbox";
            this.btn_SteamToXbox.UseVisualStyleBackColor = false;
            this.btn_SteamToXbox.Click += new System.EventHandler(this.btn_SteamToXbox_Click);
            // 
            // gb_Transfer
            // 
            this.gb_Transfer.BackColor = System.Drawing.Color.Transparent;
            this.gb_Transfer.Controls.Add(this.btn_AutoSync);
            this.gb_Transfer.Controls.Add(this.btn_SteamToXbox);
            this.gb_Transfer.Controls.Add(this.btn_XboxToSteam);
            this.gb_Transfer.ForeColor = System.Drawing.Color.Orange;
            this.gb_Transfer.Location = new System.Drawing.Point(13, 78);
            this.gb_Transfer.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.gb_Transfer.Name = "gb_Transfer";
            this.gb_Transfer.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.gb_Transfer.Size = new System.Drawing.Size(255, 133);
            this.gb_Transfer.TabIndex = 5;
            this.gb_Transfer.TabStop = false;
            this.gb_Transfer.Text = "Transfer";
            // 
            // btn_AutoSync
            // 
            this.btn_AutoSync.BackColor = System.Drawing.Color.Orange;
            this.btn_AutoSync.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_AutoSync.ForeColor = System.Drawing.Color.Black;
            this.btn_AutoSync.Location = new System.Drawing.Point(9, 20);
            this.btn_AutoSync.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btn_AutoSync.Name = "btn_AutoSync";
            this.btn_AutoSync.Size = new System.Drawing.Size(237, 29);
            this.btn_AutoSync.TabIndex = 0;
            this.btn_AutoSync.Text = "Sync Most Progress";
            this.btn_AutoSync.UseVisualStyleBackColor = false;
            this.btn_AutoSync.Click += new System.EventHandler(this.btn_AutoSync_Click);
            // 
            // btn_LocateSteamSave
            // 
            this.btn_LocateSteamSave.BackColor = System.Drawing.Color.Orange;
            this.btn_LocateSteamSave.Enabled = false;
            this.btn_LocateSteamSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_LocateSteamSave.ForeColor = System.Drawing.Color.Black;
            this.btn_LocateSteamSave.Location = new System.Drawing.Point(9, 19);
            this.btn_LocateSteamSave.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btn_LocateSteamSave.Name = "btn_LocateSteamSave";
            this.btn_LocateSteamSave.Size = new System.Drawing.Size(237, 29);
            this.btn_LocateSteamSave.TabIndex = 3;
            this.btn_LocateSteamSave.Text = "Steam save not detected";
            this.btn_LocateSteamSave.UseVisualStyleBackColor = false;
            this.btn_LocateSteamSave.Click += new System.EventHandler(this.btn_LocateSteamSave_Click);
            // 
            // btn_LocateXboxSave
            // 
            this.btn_LocateXboxSave.BackColor = System.Drawing.Color.Orange;
            this.btn_LocateXboxSave.Enabled = false;
            this.btn_LocateXboxSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_LocateXboxSave.ForeColor = System.Drawing.Color.Black;
            this.btn_LocateXboxSave.Location = new System.Drawing.Point(9, 55);
            this.btn_LocateXboxSave.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btn_LocateXboxSave.Name = "btn_LocateXboxSave";
            this.btn_LocateXboxSave.Size = new System.Drawing.Size(237, 29);
            this.btn_LocateXboxSave.TabIndex = 4;
            this.btn_LocateXboxSave.Text = "Xbox save not detected";
            this.btn_LocateXboxSave.UseVisualStyleBackColor = false;
            this.btn_LocateXboxSave.Click += new System.EventHandler(this.btn_LocateXboxSave_Click);
            // 
            // label_StatusInfo
            // 
            this.label_StatusInfo.AutoSize = true;
            this.label_StatusInfo.BackColor = System.Drawing.Color.Transparent;
            this.label_StatusInfo.Font = new System.Drawing.Font("Heavitas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_StatusInfo.ForeColor = System.Drawing.Color.Orange;
            this.label_StatusInfo.Location = new System.Drawing.Point(23, 436);
            this.label_StatusInfo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_StatusInfo.Name = "label_StatusInfo";
            this.label_StatusInfo.Size = new System.Drawing.Size(539, 16);
            this.label_StatusInfo.TabIndex = 8;
            this.label_StatusInfo.Text = "\"At least we don\'t have to haul all these save files around ourselves!\"";
            this.label_StatusInfo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label_StatusInfo.MouseMove += new System.Windows.Forms.MouseEventHandler(this.window_MouseMove);
            // 
            // menuStrip_Main
            // 
            this.menuStrip_Main.BackColor = System.Drawing.Color.Transparent;
            this.menuStrip_Main.Dock = System.Windows.Forms.DockStyle.None;
            this.menuStrip_Main.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.menuStrip_Main.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.backupToolStripMenuItem,
            this.restoreBackupsToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip_Main.Location = new System.Drawing.Point(-1, 46);
            this.menuStrip_Main.Name = "menuStrip_Main";
            this.menuStrip_Main.Padding = new System.Windows.Forms.Padding(4, 1, 0, 1);
            this.menuStrip_Main.Size = new System.Drawing.Size(577, 24);
            this.menuStrip_Main.TabIndex = 9;
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.BackColor = System.Drawing.Color.Transparent;
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.setBackupFolderToolStripMenuItem,
            this.setSteamSaveFolderToolStripMenuItem,
            this.setXboxSaveFolderToolStripMenuItem,
            this.restoreAllDefaultFoldersToolStripMenuItem});
            this.fileToolStripMenuItem.Font = new System.Drawing.Font("Heavitas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fileToolStripMenuItem.ForeColor = System.Drawing.Color.Orange;
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(105, 22);
            this.fileToolStripMenuItem.Text = "Set Folders";
            // 
            // setBackupFolderToolStripMenuItem
            // 
            this.setBackupFolderToolStripMenuItem.BackColor = System.Drawing.Color.Orange;
            this.setBackupFolderToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.chooseBackupFolderToolStripMenuItem,
            this.resetDefaultBackupFolderToolStripMenuItem});
            this.setBackupFolderToolStripMenuItem.Name = "setBackupFolderToolStripMenuItem";
            this.setBackupFolderToolStripMenuItem.Size = new System.Drawing.Size(229, 22);
            this.setBackupFolderToolStripMenuItem.Text = "Backup";
            // 
            // chooseBackupFolderToolStripMenuItem
            // 
            this.chooseBackupFolderToolStripMenuItem.BackColor = System.Drawing.Color.Orange;
            this.chooseBackupFolderToolStripMenuItem.Name = "chooseBackupFolderToolStripMenuItem";
            this.chooseBackupFolderToolStripMenuItem.Size = new System.Drawing.Size(240, 22);
            this.chooseBackupFolderToolStripMenuItem.Text = "Choose Backup Folder";
            this.chooseBackupFolderToolStripMenuItem.Click += new System.EventHandler(this.setBackupFolderToolStripMenuItem_Click);
            // 
            // resetDefaultBackupFolderToolStripMenuItem
            // 
            this.resetDefaultBackupFolderToolStripMenuItem.BackColor = System.Drawing.Color.Orange;
            this.resetDefaultBackupFolderToolStripMenuItem.Name = "resetDefaultBackupFolderToolStripMenuItem";
            this.resetDefaultBackupFolderToolStripMenuItem.Size = new System.Drawing.Size(240, 22);
            this.resetDefaultBackupFolderToolStripMenuItem.Text = "Reset to Default";
            this.resetDefaultBackupFolderToolStripMenuItem.Click += new System.EventHandler(this.resetDefaultBackupFolderToolStripMenuItem_Click);
            // 
            // setSteamSaveFolderToolStripMenuItem
            // 
            this.setSteamSaveFolderToolStripMenuItem.BackColor = System.Drawing.Color.Orange;
            this.setSteamSaveFolderToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.chooseSteamSaveFolderToolStripMenuItem1,
            this.resetDefaultSteamSaveToolStripMenuItem});
            this.setSteamSaveFolderToolStripMenuItem.Name = "setSteamSaveFolderToolStripMenuItem";
            this.setSteamSaveFolderToolStripMenuItem.Size = new System.Drawing.Size(229, 22);
            this.setSteamSaveFolderToolStripMenuItem.Text = "Steam";
            // 
            // chooseSteamSaveFolderToolStripMenuItem1
            // 
            this.chooseSteamSaveFolderToolStripMenuItem1.BackColor = System.Drawing.Color.Orange;
            this.chooseSteamSaveFolderToolStripMenuItem1.Name = "chooseSteamSaveFolderToolStripMenuItem1";
            this.chooseSteamSaveFolderToolStripMenuItem1.Size = new System.Drawing.Size(270, 22);
            this.chooseSteamSaveFolderToolStripMenuItem1.Text = "Choose Steam Save Folder";
            this.chooseSteamSaveFolderToolStripMenuItem1.Click += new System.EventHandler(this.chooseSteamSaveFolderToolStripMenuItem1_Click);
            // 
            // resetDefaultSteamSaveToolStripMenuItem
            // 
            this.resetDefaultSteamSaveToolStripMenuItem.BackColor = System.Drawing.Color.Orange;
            this.resetDefaultSteamSaveToolStripMenuItem.Name = "resetDefaultSteamSaveToolStripMenuItem";
            this.resetDefaultSteamSaveToolStripMenuItem.Size = new System.Drawing.Size(270, 22);
            this.resetDefaultSteamSaveToolStripMenuItem.Text = "Reset to Default";
            this.resetDefaultSteamSaveToolStripMenuItem.Click += new System.EventHandler(this.resetSteamFolderToolStripMenuItem_Click);
            // 
            // setXboxSaveFolderToolStripMenuItem
            // 
            this.setXboxSaveFolderToolStripMenuItem.BackColor = System.Drawing.Color.Orange;
            this.setXboxSaveFolderToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.chooseXboxSaveFolderToolStripMenuItem,
            this.resetDefaultXboxToolStripMenuItem1});
            this.setXboxSaveFolderToolStripMenuItem.Name = "setXboxSaveFolderToolStripMenuItem";
            this.setXboxSaveFolderToolStripMenuItem.Size = new System.Drawing.Size(229, 22);
            this.setXboxSaveFolderToolStripMenuItem.Text = "Xbox";
            // 
            // chooseXboxSaveFolderToolStripMenuItem
            // 
            this.chooseXboxSaveFolderToolStripMenuItem.BackColor = System.Drawing.Color.Orange;
            this.chooseXboxSaveFolderToolStripMenuItem.Name = "chooseXboxSaveFolderToolStripMenuItem";
            this.chooseXboxSaveFolderToolStripMenuItem.Size = new System.Drawing.Size(263, 22);
            this.chooseXboxSaveFolderToolStripMenuItem.Text = "Choose Xbox Save Folder";
            this.chooseXboxSaveFolderToolStripMenuItem.Click += new System.EventHandler(this.chooseXboxFolderToolStripMenuItem_Click);
            // 
            // resetDefaultXboxToolStripMenuItem1
            // 
            this.resetDefaultXboxToolStripMenuItem1.BackColor = System.Drawing.Color.Orange;
            this.resetDefaultXboxToolStripMenuItem1.Name = "resetDefaultXboxToolStripMenuItem1";
            this.resetDefaultXboxToolStripMenuItem1.Size = new System.Drawing.Size(263, 22);
            this.resetDefaultXboxToolStripMenuItem1.Text = "Reset to Default";
            this.resetDefaultXboxToolStripMenuItem1.Click += new System.EventHandler(this.resetXboxFolderToolStripMenuItem1_Click);
            // 
            // restoreAllDefaultFoldersToolStripMenuItem
            // 
            this.restoreAllDefaultFoldersToolStripMenuItem.BackColor = System.Drawing.Color.Orange;
            this.restoreAllDefaultFoldersToolStripMenuItem.Name = "restoreAllDefaultFoldersToolStripMenuItem";
            this.restoreAllDefaultFoldersToolStripMenuItem.Size = new System.Drawing.Size(229, 22);
            this.restoreAllDefaultFoldersToolStripMenuItem.Text = "Restore All Defaults";
            this.restoreAllDefaultFoldersToolStripMenuItem.Click += new System.EventHandler(this.resetAllDefaultFoldersToolStripMenuItem_Click);
            // 
            // backupToolStripMenuItem
            // 
            this.backupToolStripMenuItem.BackColor = System.Drawing.Color.Transparent;
            this.backupToolStripMenuItem.Font = new System.Drawing.Font("Heavitas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.backupToolStripMenuItem.ForeColor = System.Drawing.Color.Orange;
            this.backupToolStripMenuItem.Name = "backupToolStripMenuItem";
            this.backupToolStripMenuItem.Size = new System.Drawing.Size(133, 22);
            this.backupToolStripMenuItem.Text = "Create Backups";
            this.backupToolStripMenuItem.Click += new System.EventHandler(this.createBackupToolStripMenuItem_Click);
            // 
            // restoreBackupsToolStripMenuItem
            // 
            this.restoreBackupsToolStripMenuItem.BackColor = System.Drawing.Color.Transparent;
            this.restoreBackupsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.restoreAllToolStripMenuItem,
            this.restoreSteamToolStripMenuItem,
            this.restoreXboxToolStripMenuItem});
            this.restoreBackupsToolStripMenuItem.Font = new System.Drawing.Font("Heavitas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.restoreBackupsToolStripMenuItem.ForeColor = System.Drawing.Color.Orange;
            this.restoreBackupsToolStripMenuItem.Name = "restoreBackupsToolStripMenuItem";
            this.restoreBackupsToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.restoreBackupsToolStripMenuItem.Text = "Restore From Backup";
            // 
            // restoreAllToolStripMenuItem
            // 
            this.restoreAllToolStripMenuItem.BackColor = System.Drawing.Color.Orange;
            this.restoreAllToolStripMenuItem.Name = "restoreAllToolStripMenuItem";
            this.restoreAllToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.restoreAllToolStripMenuItem.Text = "Restore All";
            this.restoreAllToolStripMenuItem.Click += new System.EventHandler(this.restoreAllToolStripMenuItem_Click);
            // 
            // restoreSteamToolStripMenuItem
            // 
            this.restoreSteamToolStripMenuItem.BackColor = System.Drawing.Color.Orange;
            this.restoreSteamToolStripMenuItem.Name = "restoreSteamToolStripMenuItem";
            this.restoreSteamToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.restoreSteamToolStripMenuItem.Text = "Restore Steam";
            this.restoreSteamToolStripMenuItem.Click += new System.EventHandler(this.restoreSteamToolStripMenuItem_Click);
            // 
            // restoreXboxToolStripMenuItem
            // 
            this.restoreXboxToolStripMenuItem.BackColor = System.Drawing.Color.Orange;
            this.restoreXboxToolStripMenuItem.Name = "restoreXboxToolStripMenuItem";
            this.restoreXboxToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.restoreXboxToolStripMenuItem.Text = "Restore Xbox";
            this.restoreXboxToolStripMenuItem.Click += new System.EventHandler(this.restoreXboxToolStripMenuItem_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.BackColor = System.Drawing.Color.Transparent;
            this.helpToolStripMenuItem.Font = new System.Drawing.Font("Heavitas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.helpToolStripMenuItem.ForeColor = System.Drawing.Color.Orange;
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(159, 22);
            this.helpToolStripMenuItem.Text = "How Does It Work?";
            this.helpToolStripMenuItem.Click += new System.EventHandler(this.helpToolStripMenuItem_Click);
            // 
            // pictureBoxMolly
            // 
            this.pictureBoxMolly.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxMolly.Image = global::MollysGameSaveMule.Properties.Resources.molly_icon;
            this.pictureBoxMolly.Location = new System.Drawing.Point(271, 77);
            this.pictureBoxMolly.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pictureBoxMolly.Name = "pictureBoxMolly";
            this.pictureBoxMolly.Size = new System.Drawing.Size(308, 342);
            this.pictureBoxMolly.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxMolly.TabIndex = 12;
            this.pictureBoxMolly.TabStop = false;
            this.pictureBoxMolly.MouseMove += new System.Windows.Forms.MouseEventHandler(this.window_MouseMove);
            // 
            // label_Title
            // 
            this.label_Title.AutoSize = true;
            this.label_Title.BackColor = System.Drawing.Color.Transparent;
            this.label_Title.Font = new System.Drawing.Font("Heavitas", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Title.ForeColor = System.Drawing.Color.Orange;
            this.label_Title.Location = new System.Drawing.Point(6, 12);
            this.label_Title.Name = "label_Title";
            this.label_Title.Size = new System.Drawing.Size(324, 27);
            this.label_Title.TabIndex = 5;
            this.label_Title.Text = "Molly\'s Game-Save MULE";
            this.label_Title.MouseMove += new System.Windows.Forms.MouseEventHandler(this.window_MouseMove);
            // 
            // btn_Close
            // 
            this.btn_Close.BackColor = System.Drawing.Color.Black;
            this.btn_Close.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_Close.Font = new System.Drawing.Font("Heavitas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Close.ForeColor = System.Drawing.Color.Orange;
            this.btn_Close.Location = new System.Drawing.Point(541, 2);
            this.btn_Close.Name = "btn_Close";
            this.btn_Close.Size = new System.Drawing.Size(42, 30);
            this.btn_Close.TabIndex = 4;
            this.btn_Close.Text = "X";
            this.toolTip1.SetToolTip(this.btn_Close, "Close");
            this.btn_Close.UseVisualStyleBackColor = false;
            this.btn_Close.Click += new System.EventHandler(this.btn_Close_Click);
            this.btn_Close.MouseEnter += new System.EventHandler(this.btn_Close_MouseEnter);
            this.btn_Close.MouseLeave += new System.EventHandler(this.btn_Close_MouseLeave);
            // 
            // btn_Minimize
            // 
            this.btn_Minimize.BackColor = System.Drawing.Color.Black;
            this.btn_Minimize.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_Minimize.Font = new System.Drawing.Font("Heavitas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Minimize.ForeColor = System.Drawing.Color.Orange;
            this.btn_Minimize.Location = new System.Drawing.Point(498, 2);
            this.btn_Minimize.Name = "btn_Minimize";
            this.btn_Minimize.Size = new System.Drawing.Size(42, 30);
            this.btn_Minimize.TabIndex = 13;
            this.btn_Minimize.Text = "_";
            this.toolTip1.SetToolTip(this.btn_Minimize, "Minimize");
            this.btn_Minimize.UseVisualStyleBackColor = false;
            this.btn_Minimize.Click += new System.EventHandler(this.btn_Minimize_Click);
            this.btn_Minimize.MouseEnter += new System.EventHandler(this.btn_Minimize_MouseEnter);
            this.btn_Minimize.MouseLeave += new System.EventHandler(this.btn_Minimize_MouseLeave);
            // 
            // gb_Saves
            // 
            this.gb_Saves.Controls.Add(this.btn_LocateSteamSave);
            this.gb_Saves.Controls.Add(this.btn_LocateXboxSave);
            this.gb_Saves.ForeColor = System.Drawing.Color.Orange;
            this.gb_Saves.Location = new System.Drawing.Point(13, 217);
            this.gb_Saves.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.gb_Saves.Name = "gb_Saves";
            this.gb_Saves.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.gb_Saves.Size = new System.Drawing.Size(255, 97);
            this.gb_Saves.TabIndex = 6;
            this.gb_Saves.TabStop = false;
            this.gb_Saves.Text = "Saves";
            // 
            // btn_LocateXboxBackup
            // 
            this.btn_LocateXboxBackup.BackColor = System.Drawing.Color.Orange;
            this.btn_LocateXboxBackup.Enabled = false;
            this.btn_LocateXboxBackup.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_LocateXboxBackup.ForeColor = System.Drawing.Color.Black;
            this.btn_LocateXboxBackup.Location = new System.Drawing.Point(9, 55);
            this.btn_LocateXboxBackup.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btn_LocateXboxBackup.Name = "btn_LocateXboxBackup";
            this.btn_LocateXboxBackup.Size = new System.Drawing.Size(237, 29);
            this.btn_LocateXboxBackup.TabIndex = 6;
            this.btn_LocateXboxBackup.Text = "Xbox backup not detected";
            this.btn_LocateXboxBackup.UseVisualStyleBackColor = false;
            this.btn_LocateXboxBackup.Click += new System.EventHandler(this.btn_LocateXboxBackup_Click);
            // 
            // btn_LocateSteamBackup
            // 
            this.btn_LocateSteamBackup.BackColor = System.Drawing.Color.Orange;
            this.btn_LocateSteamBackup.Enabled = false;
            this.btn_LocateSteamBackup.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_LocateSteamBackup.ForeColor = System.Drawing.Color.Black;
            this.btn_LocateSteamBackup.Location = new System.Drawing.Point(9, 19);
            this.btn_LocateSteamBackup.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btn_LocateSteamBackup.Name = "btn_LocateSteamBackup";
            this.btn_LocateSteamBackup.Size = new System.Drawing.Size(237, 29);
            this.btn_LocateSteamBackup.TabIndex = 5;
            this.btn_LocateSteamBackup.Text = "Steam backup not detected";
            this.btn_LocateSteamBackup.UseVisualStyleBackColor = false;
            this.btn_LocateSteamBackup.Click += new System.EventHandler(this.btn_LocateSteamBackup_Click);
            // 
            // gb_Backups
            // 
            this.gb_Backups.BackColor = System.Drawing.Color.Transparent;
            this.gb_Backups.Controls.Add(this.btn_LocateSteamBackup);
            this.gb_Backups.Controls.Add(this.btn_LocateXboxBackup);
            this.gb_Backups.ForeColor = System.Drawing.Color.Orange;
            this.gb_Backups.Location = new System.Drawing.Point(13, 321);
            this.gb_Backups.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.gb_Backups.Name = "gb_Backups";
            this.gb_Backups.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.gb_Backups.Size = new System.Drawing.Size(255, 97);
            this.gb_Backups.TabIndex = 7;
            this.gb_Backups.TabStop = false;
            this.gb_Backups.Text = "Backups";
            // 
            // panel_Border
            // 
            this.panel_Border.BackColor = System.Drawing.Color.Black;
            this.panel_Border.Controls.Add(this.btn_Minimize);
            this.panel_Border.Controls.Add(this.label_Title);
            this.panel_Border.Controls.Add(this.btn_Close);
            this.panel_Border.Controls.Add(this.label_StatusInfo);
            this.panel_Border.Controls.Add(this.pictureBoxMolly);
            this.panel_Border.Controls.Add(this.gb_Transfer);
            this.panel_Border.Controls.Add(this.menuStrip_Main);
            this.panel_Border.Controls.Add(this.gb_Saves);
            this.panel_Border.Controls.Add(this.gb_Backups);
            this.panel_Border.Location = new System.Drawing.Point(0, 6);
            this.panel_Border.Name = "panel_Border";
            this.panel_Border.Size = new System.Drawing.Size(583, 469);
            this.panel_Border.TabIndex = 15;
            this.panel_Border.MouseMove += new System.Windows.Forms.MouseEventHandler(this.window_MouseMove);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Orange;
            this.ClientSize = new System.Drawing.Size(583, 481);
            this.Controls.Add(this.panel_Border);
            this.Font = new System.Drawing.Font("Heavitas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip_Main;
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.window_MouseMove);
            this.gb_Transfer.ResumeLayout(false);
            this.menuStrip_Main.ResumeLayout(false);
            this.menuStrip_Main.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxMolly)).EndInit();
            this.gb_Saves.ResumeLayout(false);
            this.gb_Backups.ResumeLayout(false);
            this.panel_Border.ResumeLayout(false);
            this.panel_Border.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button btn_XboxToSteam;
        private System.Windows.Forms.Button btn_SteamToXbox;
        private System.Windows.Forms.GroupBox gb_Transfer;
        private System.Windows.Forms.Button btn_LocateSteamSave;
        private System.Windows.Forms.Button btn_LocateXboxSave;
        private System.Windows.Forms.Label label_StatusInfo;
        private System.Windows.Forms.MenuStrip menuStrip_Main;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem setBackupFolderToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem setSteamSaveFolderToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem setXboxSaveFolderToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem restoreBackupsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem restoreAllToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem restoreSteamToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem restoreXboxToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem backupToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.Button btn_AutoSync;
        private System.Windows.Forms.ToolStripMenuItem chooseBackupFolderToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem resetDefaultBackupFolderToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem chooseSteamSaveFolderToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem resetDefaultSteamSaveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem chooseXboxSaveFolderToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem resetDefaultXboxToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem restoreAllDefaultFoldersToolStripMenuItem;
        private System.Windows.Forms.PictureBox pictureBoxMolly;
        private System.Windows.Forms.Label label_Title;
        private System.Windows.Forms.Button btn_Close;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.GroupBox gb_Saves;
        private System.Windows.Forms.Button btn_LocateXboxBackup;
        private System.Windows.Forms.Button btn_LocateSteamBackup;
        private System.Windows.Forms.GroupBox gb_Backups;
        private System.Windows.Forms.Panel panel_Border;
        private System.Windows.Forms.Button btn_Minimize;
    }
}

