﻿using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;

/** 
 * ntaiprogrammer 26/01/2022
 */

namespace MollysGameSaveMule
{
    public partial class messageBoxForm : Form
    {
        public messageBoxForm()
        {
            InitializeComponent();
        }

        //Creates dynamic custom message box.
        public DialogResult ShowCustomDialog(string title, string text, bool yesNo)
        {
            if (yesNo == true)
            {
                btn_Yes.Visible = true;
                btn_No.Visible = true;
            }
            else
            {
                btn_OK.Visible = true;
            }

            label_TitleBar.Text = title;
            label_Message.Text = text;

            return this.ShowDialog();
        }

        //Variables for window drag.
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();

        //Click and drag to move the window around.
        //Most form elements plugged into this event.
        private void window_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }
    }
}
